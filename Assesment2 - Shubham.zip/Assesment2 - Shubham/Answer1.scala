object Answer1 {
   def main(args: Array[String]) {
      val reverseStr = "https://www.google.com"
      val strToUpperCase = reverseStr.reverse.toUpperCase()
      println(strToUpperCase)
   }
}
