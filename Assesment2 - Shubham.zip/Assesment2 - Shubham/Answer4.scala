object Answer4 {
   def main(args: Array[String]) {
       val str = "https://www.google.com"
       val charToFind = str.charAt(8)
       println(s"The 8th character literal in $str = $charToFind")
   }
}