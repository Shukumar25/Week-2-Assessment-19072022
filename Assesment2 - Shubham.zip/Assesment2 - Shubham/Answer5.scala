object Answer5 {
   def main(args: Array[String]) {
       val item = "Glazed Donut"
       val price = 2.50
       val quantity = 10
       val totalCost = quantity * price
       
       println(f"""Total cost of $quantity $item${if (quantity > 1) "s" else ""} = $$$totalCost%1.2f""")
   }
}