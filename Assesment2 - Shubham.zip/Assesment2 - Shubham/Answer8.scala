object Answer8 {
   def main(args: Array[String]) {
       val range = List.range(100,150,10)
       val rangeStr = range.mkString(",")
       println(s"Elements of list from 100 to 150, excluding the 150 number literal = $rangeStr")
       println(s"Sum for elements in the List = ${range.sum}")
   }
}